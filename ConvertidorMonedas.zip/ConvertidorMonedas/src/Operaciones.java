
/**
 *
 * @author Marvin Pacheco
 */
public class Operaciones {
    private double valor, resultado;
    private int origen, destino;

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }

    public int getOrigen() {
        return origen;
    }

    public void setOrigen(int origen) {
        this.origen = origen;
    }

    public int getDestino() {
        return destino;
    }

    public void setDestino(int destino) {
        this.destino = destino;
    }

    public Operaciones() {
    }
    
    //Operaciones
    public double convertir(){
        if(origen==0 && destino==1){
            resultado = valor * 0.041;
            
        }else if(origen==1 && destino==0){
            resultado = valor * 24.66;
        } 
        else if(origen==0 && destino==0){
            resultado = valor;
        }
       return resultado; 
    }
    
}
